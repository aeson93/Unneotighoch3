Models from [Kenny](https://kenney.nl/assets/nature-kit).
